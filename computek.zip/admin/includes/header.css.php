<?php if($get_option==''){ ?>
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,600,700,800">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.6/css/all.css">
	<link rel="stylesheet" href="<?php echo URL_WEB_ADMIN; ?>css/black-dashboard.css?v=1.0.0" />
<?php } ?>
	<link rel="stylesheet" href="<?php echo URL_WEB_ADMIN; ?>css/animate.css" type="text/css" />
	<link rel="stylesheet" href="<?php echo URL_WEB_ADMIN; ?>css/font-awesome.min.css" type="text/css" />
	<link rel="stylesheet" href="<?php echo URL_WEB_ADMIN; ?>css/simple-line-icons.css" type="text/css" />
	<link rel="stylesheet" href="<?php echo URL_WEB_ADMIN; ?>css/bootstrap.css" type="text/css" />
	<link rel="stylesheet" href="<?php echo URL_WEB_ADMIN; ?>css/font.css" type="text/css" />
	<link rel="stylesheet" href="<?php echo URL_WEB_ADMIN; ?>css/app.css" type="text/css" />  
	<link rel="stylesheet" href="<?php echo URL_WEB_ADMIN; ?>css/jquery.fancybox.min.css"> 
	<link rel="stylesheet" href="<?php echo URL_WEB_ADMIN; ?>css/dataTables.bootstrap.min.css" type="text/css"> 
	<link rel="stylesheet" href="<?php echo URL_WEB_ADMIN; ?>css/responsive.dataTables.min.css" type="text/css" />	
	<link rel="stylesheet" href="<?php echo URL_WEB_ADMIN; ?>css/estilo.css" type="text/css" />	
 	