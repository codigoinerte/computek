<script>
function guardar_mail()
{
	document.forms[0].submit();
	return true;		
}
</script>