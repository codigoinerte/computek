<script>
function generar_backup(url_target)
{
	$('#loader').fadeIn(1000); //fadeOut(1000);
	location.href=url_target;
}
</script>