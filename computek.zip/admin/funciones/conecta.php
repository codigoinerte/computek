<?php

	$dbhost='localhost';		
	$dbusername='root';
	$dbuserpass='';
	$dbname='computek';