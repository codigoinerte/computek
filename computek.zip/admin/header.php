<?php
include("funciones/conecta.general.php");
include("funciones/definition.php");
include("funciones/funciones.php");
?>